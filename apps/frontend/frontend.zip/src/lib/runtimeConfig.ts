export * from '../shared/config/runtimeConfig';


