export { MemeCard as default } from '@/entities/meme/ui/MemeCard';
export type { MemeCardProps } from '@/entities/meme/ui/MemeCard';
