export { default } from '@/shared/ui/modals/CoinsInfoModal';

