export { default } from '@/widgets/user-menu/UserMenu';

