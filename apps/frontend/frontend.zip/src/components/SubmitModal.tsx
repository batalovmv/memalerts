export { default } from '@/features/submit/ui/SubmitModal';
export type { SubmitModalProps } from '@/features/submit/ui/SubmitModal';

