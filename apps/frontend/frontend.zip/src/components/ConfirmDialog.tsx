export { default } from '@/shared/ui/modals/ConfirmDialog';

