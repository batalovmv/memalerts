export { default } from '@/shared/ui/modals/AuthRequiredModal';


