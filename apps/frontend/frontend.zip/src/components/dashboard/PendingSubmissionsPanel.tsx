export { PendingSubmissionsPanel } from '@/features/dashboard/ui/panels/pending-submissions/PendingSubmissionsPanel';

