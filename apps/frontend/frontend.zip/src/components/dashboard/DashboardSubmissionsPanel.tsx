export { DashboardSubmissionsPanel } from '@/features/dashboard/ui/panels/submissions/DashboardSubmissionsPanel';


