export { PanelHeader as DashboardPanelHeader } from '@/features/dashboard/ui/PanelHeader';
export type { DashboardPanelHeaderProps } from '@/features/dashboard/ui/PanelHeader';


