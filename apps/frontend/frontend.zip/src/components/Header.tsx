export { default } from '@/widgets/header/Header';
export type { HeaderProps } from '@/widgets/header/Header';

