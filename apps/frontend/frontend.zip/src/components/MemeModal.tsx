export { default } from '@/entities/meme/ui/MemeModal';
