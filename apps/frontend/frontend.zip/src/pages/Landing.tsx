﻿export { default } from '@/features/landing/LandingPage';

