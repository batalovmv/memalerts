﻿export { default } from '@/features/beta-access/BetaAccessPage';

