﻿export { default } from '@/features/search/SearchPage';

