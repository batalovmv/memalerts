﻿export { default } from '@/features/settings/SettingsPage';

