﻿export { default } from '@/features/stats/StatsPage';

