﻿export { default } from '@/features/legal/PrivacyPolicyPage';

