﻿export { default } from '@/features/streamer-profile/StreamerProfilePage';

