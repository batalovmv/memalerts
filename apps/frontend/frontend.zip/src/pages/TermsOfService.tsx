﻿export { default } from '@/features/legal/TermsOfServicePage';

