﻿export { default } from '@/features/submit/SubmitPage';

