﻿import Header from '@/components/Header';
import { PageShell } from '@/shared/ui';
import { useAppSelector } from '@/store/hooks';

export default function PrivacyPolicy() {
  void useAppSelector((state) => state.auth);

  return (
    <PageShell header={<Header />}>
      <div className="surface p-8">
        <h1 className="text-3xl font-bold mb-6 text-gray-900 dark:text-white">Privacy Policy</h1>

        <div className="prose max-w-none">
          <p className="text-gray-600 dark:text-gray-400 mb-4">Last updated: {new Date().toLocaleDateString()}</p>

          <section className="mb-6">
            <h2 className="text-2xl font-semibold mb-3">1. Information We Collect</h2>
            <p className="text-gray-800 dark:text-gray-200 mb-2">
              We collect information that you provide directly to us, including:
            </p>
            <ul className="list-disc list-inside text-gray-800 dark:text-gray-200 ml-4">
              <li>Twitch account information (display name, user ID)</li>
              <li>Content you submit (memes, titles, tags, notes)</li>
              <li>Usage data and analytics</li>
            </ul>
          </section>

            <section className="mb-6">
              <h2 className="text-2xl font-semibold mb-3">2. How We Use Your Information</h2>
              <p className="text-gray-800 dark:text-gray-200 mb-2">We use the information we collect to:</p>
              <ul className="list-disc list-inside text-gray-800 dark:text-gray-200 ml-4">
                <li>Provide, maintain, and improve our services</li>
                <li>Process and manage meme submissions</li>
                <li>Manage user balances and transactions</li>
                <li>Send you technical notices and support messages</li>
              </ul>
            </section>

            <section className="mb-6">
              <h2 className="text-2xl font-semibold mb-3">3. Information Sharing</h2>
              <p className="text-gray-800 dark:text-gray-200">
                We do not sell, trade, or otherwise transfer your personal information to third parties without your consent, 
                except as described in this policy. We may share information with service providers who assist us in operating 
                our website and conducting our business.
              </p>
            </section>

            <section className="mb-6">
              <h2 className="text-2xl font-semibold mb-3">4. Data Security</h2>
              <p className="text-gray-800 dark:text-gray-200">
                We implement appropriate security measures to protect your personal information. However, no method of transmission 
                over the Internet or electronic storage is 100% secure, and we cannot guarantee absolute security.
              </p>
            </section>

            <section className="mb-6">
              <h2 className="text-2xl font-semibold mb-3">5. Cookies</h2>
              <p className="text-gray-800 dark:text-gray-200">
                We use cookies to maintain your session and authenticate you. You can control cookies through your browser settings, 
                but this may affect your ability to use certain features of our service.
              </p>
            </section>

            <section className="mb-6">
              <h2 className="text-2xl font-semibold mb-3">6. Your Rights</h2>
              <p className="text-gray-800 dark:text-gray-200">
                You have the right to access, update, or delete your personal information. You can also opt out of certain data 
                collection practices. To exercise these rights, please contact us.
              </p>
            </section>

            <section className="mb-6">
              <h2 className="text-2xl font-semibold mb-3">7. Changes to This Policy</h2>
              <p className="text-gray-800 dark:text-gray-200">
                We may update this privacy policy from time to time. We will notify you of any changes by posting the new policy 
                on this page and updating the &quot;Last updated&quot; date.
              </p>
            </section>

            <section className="mb-6">
              <h2 className="text-2xl font-semibold mb-3">8. Contact Us</h2>
              <p className="text-gray-800 dark:text-gray-200">
                If you have any questions about this Privacy Policy, please contact us through our website.
              </p>
            </section>
        </div>
      </div>
    </PageShell>
  );
}


