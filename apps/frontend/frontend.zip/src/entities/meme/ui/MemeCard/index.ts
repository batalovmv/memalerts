export { MemeCard } from './MemeCard';
export type { MemeCardProps } from './MemeCard';


